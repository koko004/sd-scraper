import { useState } from 'react';

// Types
interface System {
  id: string;
  name: string;
  icon: string;
  roms: number;
  missing: number;
}

interface Game {
  id: number;
  system: string;
  name: string;
  filename: string;
}

interface DownloadedCover {
  id: number;
  game: string;
  system: string;
  image: string;
  date: string;
}

interface LogEntry {
  id: number;
  message: string;
  type: 'info' | 'success' | 'error';
}

// Sample systems with retro console icons
const initialSystems: System[] = [
  { id: 'nes', name: 'NES', icon: '🎮', roms: 142, missing: 31 },
  { id: 'snes', name: 'SNES', icon: '🕹️', roms: 87, missing: 19 },
  { id: 'gb', name: 'GAME BOY', icon: '📱', roms: 113, missing: 27 },
  { id: 'gba', name: 'GBA', icon: '📱', roms: 76, missing: 14 },
  { id: 'genesis', name: 'GENESIS', icon: '🕹️', roms: 68, missing: 22 },
  { id: 'sms', name: 'MASTER SYSTEM', icon: '🎮', roms: 54, missing: 11 },
  { id: 'n64', name: 'NINTENDO 64', icon: '🕹️', roms: 39, missing: 9 },
  { id: 'psx', name: 'PLAYSTATION', icon: '💿', roms: 61, missing: 15 },
];

// Sample games for demo scraping
const sampleGames: { [key: string]: Game[] } = {
  nes: [
    { id: 1, system: 'nes', name: 'SUPER MARIO BROS', filename: 'Super Mario Bros.nes' },
    { id: 2, system: 'nes', name: 'THE LEGEND OF ZELDA', filename: 'Zelda.nes' },
    { id: 3, system: 'nes', name: 'METROID', filename: 'Metroid.nes' },
    { id: 4, system: 'nes', name: 'MEGA MAN 2', filename: 'Mega Man 2.nes' },
  ],
  snes: [
    { id: 5, system: 'snes', name: 'SUPER MARIO WORLD', filename: 'SMW.smc' },
    { id: 6, system: 'snes', name: 'THE LEGEND OF ZELDA: A LINK TO THE PAST', filename: 'Zelda3.smc' },
    { id: 7, system: 'snes', name: 'CHRONO TRIGGER', filename: 'Chrono Trigger.smc' },
  ],
  gb: [
    { id: 8, system: 'gb', name: 'SUPER MARIO LAND', filename: 'Mario Land.gb' },
    { id: 9, system: 'gb', name: 'TETRIS', filename: 'Tetris.gb' },
    { id: 10, system: 'gb', name: 'POKEMON RED', filename: 'Pokemon Red.gb' },
  ],
  gba: [
    { id: 11, system: 'gba', name: 'POKEMON FIRE RED', filename: 'FireRed.gba' },
    { id: 12, system: 'gba', name: 'METROID FUSION', filename: 'Fusion.gba' },
  ],
  genesis: [
    { id: 13, system: 'genesis', name: 'SONIC THE HEDGEHOG', filename: 'Sonic.bin' },
    { id: 14, system: 'genesis', name: 'STREETS OF RAGE 2', filename: 'SoR2.bin' },
    { id: 15, system: 'genesis', name: 'GOLDEN AXE', filename: 'Golden Axe.bin' },
  ],
  sms: [
    { id: 16, system: 'sms', name: 'SONIC THE HEDGEHOG', filename: 'Sonic.sms' },
    { id: 17, system: 'sms', name: 'PHANTASY STAR', filename: 'Phantasy.sms' },
  ],
  n64: [
    { id: 18, system: 'n64', name: 'SUPER MARIO 64', filename: 'Mario64.z64' },
    { id: 19, system: 'n64', name: 'THE LEGEND OF ZELDA: OOT', filename: 'ZeldaOOT.z64' },
  ],
  psx: [
    { id: 20, system: 'psx', name: 'FINAL FANTASY VII', filename: 'FF7.bin' },
    { id: 21, system: 'psx', name: 'METAL GEAR SOLID', filename: 'MGS.bin' },
  ],
};

// Cover images mapping
const coverImages: { [key: string]: string } = {
  'SUPER MARIO BROS': '/images/cover-mario.jpg',
  'THE LEGEND OF ZELDA': '/images/cover-zelda.jpg',
  'SONIC THE HEDGEHOG': '/images/cover-sonic.jpg',
  'SUPER MARIO LAND': '/images/cover-mb.jpg',
  'MEGA MAN 2': '/images/cover-pacman.jpg',
};

const destinationOptions = [
  { value: 'images', label: 'images/' },
  { value: 'media', label: 'media/' },
  { value: 'custom', label: 'custom/' },
];

export default function SDScrapperRetro() {
  // States
  const [credentials, setCredentials] = useState({
    ssid: 'retrofan88',
    sspass: '********',
    devid: 'SS_SCRAPPER',
    devpass: 'dev2024',
  });
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [loggedUser, setLoggedUser] = useState('');

  const [folderSelected, setFolderSelected] = useState(false);
  const [folderPath, setFolderPath] = useState('');
  const [systems, setSystems] = useState<System[]>([]);
  const [selectedSystems, setSelectedSystems] = useState<string[]>([]);

  const [destFolder, setDestFolder] = useState('media');
  const [downloadBoxart, setDownloadBoxart] = useState(true);
  const [downloadVideos, setDownloadVideos] = useState(false);

  // Scraping states
  const [isScraping, setIsScraping] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentSystem, setCurrentSystem] = useState('');
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [processedCount, setProcessedCount] = useState(0);
  const [totalToProcess, setTotalToProcess] = useState(0);

  // Gallery
  const [downloadedCovers, setDownloadedCovers] = useState<DownloadedCover[]>([]);
  const [showGallery, setShowGallery] = useState(false);

  // Add log helper
  const addLog = (message: string, type: 'info' | 'success' | 'error' = 'info') => {
    const newLog: LogEntry = {
      id: Date.now(),
      message,
      type,
    };
    setLogs(prev => [...prev.slice(-18), newLog]);
  };

  // Simulate login to ScreenScraper
  const handleLogin = () => {
    if (!credentials.ssid || !credentials.sspass) {
      addLog('ERROR: Enter valid ScreenScraper credentials', 'error');
      return;
    }
    
    setIsLoggedIn(true);
    setLoggedUser(credentials.ssid.toUpperCase());
    addLog(`CONNECTED TO SCREENSCRAPER.FR`, 'success');
    addLog(`USER: ${credentials.ssid} | CREDITS: 850`, 'info');
  };

  // Simulate selecting MicroSD folder
  const handleSelectFolder = () => {
    const demoPath = '/Volumes/RETRO_SD/ROMS/';
    setFolderPath(demoPath);
    setFolderSelected(true);
    addLog('MICRO-SD MOUNTED SUCCESSFULLY', 'success');
    addLog(`PATH: ${demoPath}`, 'info');
  };

  // Scan the ROMs - load systems
  const handleScanRoms = () => {
    if (!folderSelected) {
      addLog('INSERT MICRO-SD FIRST', 'error');
      return;
    }

    // Load systems with slight randomization for demo
    const scannedSystems = initialSystems.map(sys => ({
      ...sys,
      missing: Math.floor(sys.missing * (0.8 + Math.random() * 0.4)),
    }));

    setSystems(scannedSystems);
    setSelectedSystems(scannedSystems.map(s => s.id)); // Select all by default
    
    addLog('ROM SCAN COMPLETE', 'success');
    addLog(`${scannedSystems.length} SYSTEMS DETECTED`, 'info');
    addLog(`${scannedSystems.reduce((a, s) => a + s.missing, 0)} COVERS MISSING`, 'info');
  };

  // Toggle system selection
  const toggleSystem = (systemId: string) => {
    if (selectedSystems.includes(systemId)) {
      setSelectedSystems(prev => prev.filter(id => id !== systemId));
    } else {
      setSelectedSystems(prev => [...prev, systemId]);
    }
  };

  // Start the scraping process - FULLY FUNCTIONAL SIMULATION
  const startScraping = async () => {
    if (!isLoggedIn) {
      addLog('LOGIN TO SCREENSCRAPER REQUIRED', 'error');
      return;
    }
    if (selectedSystems.length === 0 || systems.length === 0) {
      addLog('SELECT SYSTEMS TO SCRAP', 'error');
      return;
    }

    setIsScraping(true);
    setProgress(0);
    setLogs([]);
    setProcessedCount(0);
    setDownloadedCovers([]);

    addLog('INITIALIZING SCREENSCRAPER SCRAPPER v2.4', 'info');
    addLog('AUTHENTICATING WITH API...', 'info');

    // Collect all missing games to process
    const gamesToProcess: Game[] = [];
    selectedSystems.forEach(sysId => {
      const systemGames = sampleGames[sysId] || [];
      systemGames.forEach(game => gamesToProcess.push(game));
    });

    setTotalToProcess(gamesToProcess.length);

    let completed = 0;
    const newCovers: DownloadedCover[] = [];

    // Simulate processing
    for (let i = 0; i < gamesToProcess.length; i++) {
      const game = gamesToProcess[i];
      const sysName = systems.find(s => s.id === game.system)?.name || game.system;

      setCurrentSystem(sysName);

      // Progress update
      const prog = Math.floor(((i + 1) / gamesToProcess.length) * 100);
      setProgress(prog);
      setProcessedCount(i + 1);

      // Log sequence
      addLog(`SEARCHING: ${game.name} [${sysName}]`, 'info');
      
      await new Promise(resolve => setTimeout(resolve, 580));

      // Simulate API result
      const success = Math.random() > 0.12; // 88% success rate

      if (success) {
        const coverUrl = coverImages[game.name] || '/images/cover-mario.jpg';
        
        addLog(`COVER FOUND: ${game.name}`, 'success');
        await new Promise(resolve => setTimeout(resolve, 340));

        addLog(`DOWNLOADING TO ${destFolder}/${game.name.replace(/\s/g, '_')}.png`, 'info');

        // Add to gallery
        const newCover: DownloadedCover = {
          id: Date.now() + i,
          game: game.name,
          system: sysName,
          image: coverUrl,
          date: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        newCovers.push(newCover);

        await new Promise(resolve => setTimeout(resolve, 420));
        addLog(`✓ SAVED SUCCESSFULLY`, 'success');
      } else {
        addLog(`NO MATCH FOUND - SKIPPING`, 'error');
      }

      setDownloadedCovers([...newCovers]);
      completed = i + 1;
    }

    // Finish
    setTimeout(() => {
      setProgress(100);
      addLog('SCRAPING COMPLETE!', 'success');
      addLog(`${completed}/${gamesToProcess.length} COVERS DOWNLOADED`, 'success');
      addLog('MICRO-SD UPDATED SUCCESSFULLY', 'success');
      
      setTimeout(() => {
        setIsScraping(false);
        setCurrentSystem('');
      }, 1400);
    }, 800);
  };

  // Reset everything
  const resetAll = () => {
    setIsScraping(false);
    setProgress(0);
    setLogs([]);
    setProcessedCount(0);
    setDownloadedCovers([]);
    setFolderSelected(false);
    setFolderPath('');
    setSystems([]);
    setSelectedSystems([]);
    setShowGallery(false);
    setCurrentSystem('');
    setIsLoggedIn(false);
    addLog('SYSTEM RESET', 'info');
  };

  // Open gallery modal
  const openGallery = () => {
    if (downloadedCovers.length > 0) {
      setShowGallery(true);
    }
  };

  // Current selected missing count
  const totalMissing = systems
    .filter(s => selectedSystems.includes(s.id))
    .reduce((sum, s) => sum + s.missing, 0);

  return (
    <div className="min-h-screen bg-[#0a0c10] text-[#00ff41] overflow-hidden">
      {/* CRT Header */}
      <div className="border-b-4 border-[#2a2f38] bg-[#11151b]">
        <div className="max-w-7xl mx-auto px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-[#1a1f26] border-4 border-[#00ff41] flex items-center justify-center text-3xl rounded-sm">
                📼
              </div>
              <div>
                <h1 className="text-4xl font-bold tracking-[4px] text-[#39ff14]">SD SCRAPPER</h1>
                <div className="text-xs tracking-[3px] text-[#ffaa00] -mt-1">RETRO COVER MANAGER v2.4</div>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-6 text-sm">
            <div className="flex items-center gap-2">
              <div className="led led-green"></div>
              <span className="text-[#00ff41]/70">SCREENSCRAPER.FR</span>
            </div>
            <div className="px-4 py-1 bg-[#1a1f26] border border-[#2a2f38] text-xs tracking-widest">
              FOR R36S • ARKOS
            </div>
          </div>

          <button 
            onClick={resetAll} 
            className="retro-btn px-5 py-2 text-xs"
          >
            RESET SYSTEM
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Status Bar */}
        <div className="mb-8 flex items-center justify-between text-xs border-b border-[#2a2f38] pb-4">
          <div className="flex items-center gap-8">
            <div>STATUS: <span className="text-[#ffaa00] font-bold">{isScraping ? 'SCRAPPING' : isLoggedIn ? 'READY' : 'AWAITING LOGIN'}</span></div>
            {folderSelected && <div>FOLDER: <span className="text-white/80">{folderPath}</span></div>}
            {systems.length > 0 && <div>SYSTEMS: <span className="text-white/80">{systems.length}</span></div>}
          </div>
          {loggedUser && (
            <div className="text-[#ffaa00]">CONNECTED AS: <span className="font-bold text-white">{loggedUser}</span></div>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* CREDENTIALS PANEL */}
          <div className="lg:col-span-4 retro-panel crt p-6">
            <div className="flex items-center gap-3 mb-5">
              <div className="text-xl">🔐</div>
              <div>
                <div className="text-[#ffaa00] text-sm tracking-[2px]">SCREENSCRAPER.FR</div>
                <div className="font-bold text-lg -mt-1">CREDENTIALS</div>
              </div>
            </div>

            {!isLoggedIn ? (
              <div className="space-y-4">
                <div>
                  <div className="text-xs mb-1.5 tracking-widest text-[#ffaa00]/80">SSID / USERNAME</div>
                  <input 
                    type="text" 
                    value={credentials.ssid} 
                    onChange={(e) => setCredentials({...credentials, ssid: e.target.value})}
                    className="retro-input w-full text-lg"
                    placeholder="YOUR USERNAME"
                  />
                </div>
                <div>
                  <div className="text-xs mb-1.5 tracking-widest text-[#ffaa00]/80">SSPASS / PASSWORD</div>
                  <input 
                    type="password" 
                    value={credentials.sspass} 
                    onChange={(e) => setCredentials({...credentials, sspass: e.target.value})}
                    className="retro-input w-full text-lg"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3 pt-1">
                  <div>
                    <div className="text-xs mb-1.5 tracking-widest text-[#ffaa00]/80">DEV ID</div>
                    <input type="text" value={credentials.devid} onChange={(e) => setCredentials({...credentials, devid: e.target.value})} className="retro-input w-full text-sm" />
                  </div>
                  <div>
                    <div className="text-xs mb-1.5 tracking-widest text-[#ffaa00]/80">DEV PASS</div>
                    <input type="text" value={credentials.devpass} onChange={(e) => setCredentials({...credentials, devpass: e.target.value})} className="retro-input w-full text-sm" />
                  </div>
                </div>
                
                <button onClick={handleLogin} className="retro-btn w-full py-3.5 text-base mt-2 tracking-[1.5px]">
                  VERIFY ACCOUNT &amp; CONNECT
                </button>
                <div className="text-center text-[10px] text-[#ffaa00]/60 tracking-widest">FREE ACCOUNT REQUIRED</div>
              </div>
            ) : (
              <div className="py-4">
                <div className="flex items-center justify-center gap-3 mb-6">
                  <div className="led led-green"></div>
                  <div className="text-xl font-bold">CONNECTED</div>
                </div>
                <div className="text-center text-sm bg-[#1a1f26] py-4 border border-[#2a2f38]">
                  <div className="text-[#ffaa00]">WELCOME, {loggedUser}</div>
                  <div className="text-xs mt-1 opacity-70">850 SCRAP CREDITS REMAINING</div>
                </div>
              </div>
            )}
          </div>

          {/* MICROSD + SCAN PANEL */}
          <div className="lg:col-span-5 retro-panel crt p-6">
            <div className="flex justify-between items-start mb-5">
              <div>
                <div className="flex items-center gap-3">
                  <div className="text-xl">💾</div>
                  <div>
                    <div className="text-[#ffaa00] text-sm tracking-[2px]">MICRO-SD CARD</div>
                    <div className="font-bold text-lg -mt-1">ROM STORAGE</div>
                  </div>
                </div>
              </div>
              {folderSelected && (
                <div className="px-3 py-1 text-xs border border-[#00ff41] text-[#00ff41]">MOUNTED</div>
              )}
            </div>

            {!folderSelected ? (
              <button 
                onClick={handleSelectFolder} 
                className="retro-btn w-full py-8 text-xl tracking-[3px]"
              >
                INSERT MICRO-SD FOLDER
              </button>
            ) : (
              <div>
                <div className="bg-[#0a0c10] border-4 border-[#2a2f38] p-4 mb-4 font-mono text-sm">
                  {folderPath}<br />
                  <span className="text-[#ffaa00]">✓ READY FOR SCANNING</span>
                </div>
                
                <button 
                  onClick={handleScanRoms}
                  disabled={systems.length > 0}
                  className="retro-btn w-full py-3 text-base tracking-widest"
                >
                  {systems.length > 0 ? 'ROMS SCANNED' : 'SCAN ROM DIRECTORIES'}
                </button>
              </div>
            )}

            {systems.length > 0 && (
              <div className="mt-4 text-xs flex justify-between items-center border-t border-[#2a2f38] pt-4">
                <div>TOTAL ROMS DETECTED: <span className="text-white">{systems.reduce((a, s) => a + s.roms, 0)}</span></div>
                <div>MISSING COVERS: <span className="text-[#ffaa00] font-bold">{totalMissing}</span></div>
              </div>
            )}
          </div>

          {/* OPTIONS */}
          <div className="lg:col-span-3 retro-panel crt p-6">
            <div className="mb-4">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xl">⚙︎</span>
                <span className="font-bold text-lg tracking-wide">CONFIG</span>
              </div>
            </div>

            <div className="space-y-4 text-sm">
              <div>
                <div className="text-xs text-[#ffaa00]/70 mb-2 tracking-widest">DESTINATION FOLDER</div>
                <div className="space-y-1">
                  {destinationOptions.map(opt => (
                    <label key={opt.value} className="flex items-center gap-3 cursor-pointer hover:text-white">
                      <input 
                        type="radio" 
                        name="dest" 
                        checked={destFolder === opt.value} 
                        onChange={() => setDestFolder(opt.value)}
                        className="accent-[#00ff41]"
                      />
                      <span className="font-mono text-xs">{opt.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="pt-2 border-t border-[#2a2f38]">
                <div className="text-xs text-[#ffaa00]/70 mb-2 tracking-widest">MEDIA OPTIONS</div>
                <label className="flex items-center gap-3 cursor-pointer mb-1.5">
                  <input type="checkbox" checked={downloadBoxart} onChange={(e) => setDownloadBoxart(e.target.checked)} className="accent-[#00ff41] w-4 h-4" />
                  <span>DOWNLOAD BOXART (2D)</span>
                </label>
                <label className="flex items-center gap-3 cursor-pointer">
                  <input type="checkbox" checked={downloadVideos} onChange={(e) => setDownloadVideos(e.target.checked)} className="accent-[#00ff41] w-4 h-4" />
                  <span>DOWNLOAD VIDEOS (MP4)</span>
                </label>
              </div>
            </div>
          </div>

          {/* SYSTEMS GRID */}
          {systems.length > 0 && (
            <div className="lg:col-span-12 retro-panel crt p-6 mt-2">
              <div className="flex justify-between items-center mb-5">
                <div>
                  <div className="text-[#ffaa00] text-sm tracking-[3px]">AVAILABLE CONSOLES</div>
                  <div className="font-bold text-2xl tracking-wide">SELECT SYSTEMS TO SCRAP</div>
                </div>
                <div className="text-right text-xs">
                  <div>{selectedSystems.length} / {systems.length} SELECTED</div>
                  <div className="text-[#ffaa00]">{totalMissing} COVERS PENDING</div>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
                {systems.map((system) => {
                  const isSelected = selectedSystems.includes(system.id);
                  return (
                    <div 
                      key={system.id}
                      onClick={() => toggleSystem(system.id)}
                      className={`system-card p-4 cursor-pointer flex flex-col items-center text-center ${isSelected ? 'selected' : ''}`}
                    >
                      <div className="text-4xl mb-2 opacity-90">{system.icon}</div>
                      <div className="font-bold text-sm tracking-widest mb-1">{system.name}</div>
                      <div className="text-[10px] text-[#ffaa00] font-mono mb-1">{system.roms} ROMS</div>
                      <div className={`inline-block px-3 py-px text-xs border ${isSelected ? 'border-[#ffaa00] text-[#ffaa00]' : 'border-[#2a2f38] text-white/60'}`}>
                        {system.missing} MISSING
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ACTION BAR */}
          <div className="lg:col-span-12 flex flex-wrap items-center gap-4 justify-between mt-3">
            <div className="flex items-center gap-4">
              <button 
                onClick={startScraping} 
                disabled={!isLoggedIn || selectedSystems.length === 0 || isScraping || systems.length === 0}
                className="retro-btn px-14 py-4 text-xl tracking-[4px] disabled:opacity-40"
              >
                {isScraping ? 'SCRAPPING IN PROGRESS...' : 'START SCRAPPING COVERS'}
              </button>
              
              {downloadedCovers.length > 0 && !isScraping && (
                <button 
                  onClick={openGallery}
                  className="retro-btn px-8 py-4 border-[#ffaa00] text-[#ffaa00] tracking-[2px]"
                >
                  VIEW GALLERY ({downloadedCovers.length})
                </button>
              )}
            </div>

            <div className="text-xs text-[#ffaa00]/60 tracking-widest">
              DEMO MODE • SIMULATES FILE SYSTEM ACCESS API
            </div>
          </div>

          {/* SCRAPING PROGRESS PANEL */}
          {isScraping && (
            <div className="lg:col-span-12 retro-panel crt p-8 mt-4 border-[#ffaa00]">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <div className="font-bold text-xl tracking-[2px]">SCRAPPING IN PROGRESS</div>
                  <div className="text-[#ffaa00] text-xs tracking-widest mt-px">SCREENSCRAPER API • LIVE FEED</div>
                </div>
                <div className="text-right">
                  <div className="font-mono text-2xl tabular-nums tracking-widest">{progress}<span className="text-sm align-super">%</span></div>
                  <div className="text-xs text-white/60">{processedCount} / {totalToProcess} PROCESSED</div>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="retro-progress mb-6">
                <div 
                  className="retro-progress-bar" 
                  style={{ width: `${progress}%` }}
                />
              </div>

              {/* Current System Status */}
              {currentSystem && (
                <div className="text-sm mb-3 flex items-center gap-3">
                  <span className="text-[#ffaa00]">CURRENT SYSTEM:</span> 
                  <span className="font-bold tracking-widest">{currentSystem}</span>
                </div>
              )}

              {/* Terminal Log */}
              <div className="terminal p-4 font-mono text-xs leading-relaxed">
                {logs.length === 0 && <div className="opacity-60">INITIALIZING...</div>}
                {logs.map(log => (
                  <div key={log.id} className={
                    log.type === 'success' ? 'text-[#39ff14]' : 
                    log.type === 'error' ? 'text-[#ff3355]' : 'text-[#00cc33]'
                  }>
                    [{new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit', second:'2-digit'})}] {log.message}
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>
      </div>

      {/* Footer */}
      <div className="border-t-4 border-[#2a2f38] py-4 text-center text-xs text-[#00ff41]/50 tracking-[2px]">
        SD SCRAPPER RETRO • BUILT FOR RETRO GAMING ENTHUSIASTS • POWERED BY SCREENSCRAPER.FR
      </div>

      {/* GALLERY MODAL - Retro Style */}
      {showGallery && (
        <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-6" onClick={() => setShowGallery(false)}>
          <div className="max-w-6xl w-full retro-panel crt p-8" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-8">
              <div>
                <div className="text-[#ffaa00] tracking-[4px] text-sm">DOWNLOADED MEDIA</div>
                <div className="text-4xl tracking-[3px] font-bold">COVER GALLERY</div>
              </div>
              <button onClick={() => setShowGallery(false)} className="retro-btn px-8 py-3">CLOSE GALLERY</button>
            </div>

            {downloadedCovers.length === 0 ? (
              <div className="py-16 text-center text-lg opacity-60">No covers downloaded yet.</div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-5">
                {downloadedCovers.map((cover, idx) => (
                  <div key={idx} className="cover-card group">
                    <div className="cover-frame p-2">
                      <div className="aspect-[4/3] bg-black overflow-hidden relative">
                        <img 
                          src={cover.image} 
                          alt={cover.game} 
                          className="w-full h-full object-cover grayscale-[0.3] group-hover:grayscale-0 transition-all duration-300" 
                        />
                        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 to-transparent p-3">
                          <div className="font-bold text-xs tracking-widest text-[#00ff41]">{cover.game}</div>
                          <div className="text-[10px] text-white/60 mt-px">{cover.system} • {cover.date}</div>
                        </div>
                      </div>
                    </div>
                    <div className="px-3 py-2 text-center text-[10px] text-[#ffaa00] border-t border-[#2a2f38]">
                      SAVED TO {destFolder}/
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div className="text-center text-xs mt-8 text-[#ffaa00]/60 tracking-widest">
              ALL COVERS DOWNLOADED FROM SCREENSCRAPER.FR — READY FOR YOUR RETRO CONSOLE
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
